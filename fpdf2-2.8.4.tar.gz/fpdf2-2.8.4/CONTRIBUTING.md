Please check [the documentation page dedicated to development](https://py-pdf.github.io/fpdf2/Development.html).

You will also get some guidelines whenever you start [opening an issue](https://github.com/py-pdf/fpdf2/issues)
or [submitting a Pull Request](https://github.com/py-pdf/fpdf2/pulls).

If you're new to contributing to open source projects,
you might find this free video course helpful: http://kcd.im/pull-request

This library was only possible thanks to the dedication of the following people: [CONTRIBUTORS.md](CONTRIBUTORS.md).
